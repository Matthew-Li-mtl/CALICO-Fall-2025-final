#include <iostream>
#include <vector>
#include <string>

using namespace std;

/**
 * Return the number of subsequences of owo and uwu
 * 
 * S: string of characters
 */
int solve(string S) {
    //YOUR CODE HERE
    return -1;
}

int main() {
    int T;
    cin >> T;
    for (int i = 0; i < T; i++) {
        string S;
        cin >> S;
        cout << solve(S) << '\n';
    }
}