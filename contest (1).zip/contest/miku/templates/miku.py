def solve(S):
    """
    Return the number of subsequences of owo and uwu
    
    S: string of characters 
    """
    # YOUR CODE HERE
    return -1

def main():
    T = int(input())
    for _ in range(T):
        S = input()
        print(solve(S))
main()
